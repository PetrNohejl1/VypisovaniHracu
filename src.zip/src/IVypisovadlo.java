
public interface IVypisovadlo {
	public String preved(int aktual, int max);
	public String preved(int num);
}
